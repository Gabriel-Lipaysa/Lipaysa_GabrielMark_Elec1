<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
</head>
<body>

    <nav class="navbar navbar-light bg-light px-4 d-flex justify-content-between">
        <span class="navbar-brand mb-0 h1">Dashboard</span>

        <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">Logout</button>
        </form>
    </nav>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\authentication\resources\views/dashboard.blade.php ENDPATH**/ ?>